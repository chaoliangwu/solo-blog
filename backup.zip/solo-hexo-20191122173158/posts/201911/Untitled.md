title: Untitled
date: '2019-11-20 15:32:02'
updated: '2019-11-20 15:32:02'
tags: [Note]
permalink: /articles/2019/11/20/1574235121927.html
---
[2019-03-22 09:20:13,027] [INFO] [c.b.seccore.filter.ProviderFilter][58f5c8dc-1d30-4447-998e-2090856e8f03] traceLogid:[58f5c8dc-1d30-4447-998e-2090856e8f03] dstTraceId:[84391571376f4ac8983c5162cc039a7c] call [DataSecuritySerivce] [verifyMac] [1ms] [mac校验失败] [100014] **RESPONSE:null**





**KMIP（Key Management Interoperability Protocol）是一种通信协议，该协议定义了在秘钥管理服务器上操作加密秘钥的消息格式。秘钥可能在服务器上被创建、和检索，可能被其他秘钥封装。需要支持对称和非对称秘钥，支持证书签名。KMIP还定义了用于在服务器上执行加密操作的消息，如：加密和解密。**



https://blog.csdn.net/lihuayong/article/details/25533849



库:

https://github.com/geekfivestart/dse67





https://www.jianshu.com/p/ea44224b9cba

guava





vue apollo

apollo-server-koa